# 随记交接包

给实现 Agent：先阅读 `suiji-agent-handoff.md`，再看 `prototype/`。

- `suiji-agent-handoff.md`：唯一主交接文档，包含确认需求、排除项、数据库/MCP 建议、实施阶段、验收用例与未决事项。
- `prototype/index.html`、`prototype/styles.css`、`prototype/app.js`：最新保存的版本 4 原型资源，标签和独立 URL 字段已移除。打开 index.html 默认显示方案 A。
- `MANIFEST.sha256`：文件完整性清单。

这是交接资料，不是完整生产实现。原型只有内存示例数据和演示 AI，刷新重置。

截至 2026-09-05 本次整理，线上已发布的是版本 3，仍有标签；版本 4 已保存但没有发布。以本文与包内源码为准，不要重新加入标签。

原型源码快照 commit：`3ee37c668cb292d9dd4c89691862835ebef170f4`。

源码没有携带登录令牌、数据库连接串、Git 凭据、部署 manifest 或真实用户数据。接手方不需要访问原工作区即可参考交互。
